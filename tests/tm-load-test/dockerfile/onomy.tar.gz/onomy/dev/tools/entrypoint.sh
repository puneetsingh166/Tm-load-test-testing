mkdir -p /cache/golangci-lint/ /cache/go-build/

exec "$@"